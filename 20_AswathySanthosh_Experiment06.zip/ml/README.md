# Logistic Regression for Diabetes Prediction

## Overview

This project implements a **Logistic Regression** model to predict whether a person has diabetes using the **Pima Indians Diabetes** dataset. The model is trained and evaluated both **with and without feature scaling** to analyze the impact of preprocessing on classification performance.

---

## Objectives

* Load and preprocess the Pima Indians Diabetes dataset.
* Implement Logistic Regression for binary classification.
* Compare model performance with and without feature scaling.
* Evaluate the classifier using Accuracy, Precision, Recall, and F1-score.

---

## Dataset

The project uses the **Pima Indians Diabetes Dataset**, which has been downloaded and stored locally as **`diabetes.csv`**.

The dataset contains medical information collected from female patients of Pima Indian heritage and is commonly used for diabetes prediction tasks.

### Features

* Pregnancies
* Glucose
* BloodPressure
* SkinThickness
* Insulin
* BMI
* DiabetesPedigreeFunction
* Age

### Target Variable

* **Outcome = 0** → Non-diabetic
* **Outcome = 1** → Diabetic

---

## Requirements

Install the required Python libraries before running the program:

```bash
pip install pandas scikit-learn
```

---

## Program Workflow

### 1. Load the Dataset

The program reads the downloaded dataset from the local file:

```python
df = pd.read_csv("diabetes.csv")
```

The input features (`X`) and target variable (`Outcome`) are then separated.

### 2. Split the Dataset

The dataset is divided into training (80%) and testing (20%) sets using `train_test_split()`.

### 3. Train Logistic Regression (Without Feature Scaling)

A Logistic Regression model is trained using the original feature values without applying any scaling. Predictions are made on the test data.

### 4. Evaluate the Model

The model is evaluated using:

* Accuracy
* Precision
* Recall
* F1-score
* Confusion Matrix
* Classification Report

### 5. Apply Feature Scaling

The `StandardScaler` standardizes the feature values so that each feature has a mean of 0 and a standard deviation of 1.

### 6. Train Logistic Regression (With Feature Scaling)

Another Logistic Regression model is trained using the scaled training data, and predictions are made on the scaled test data.

### 7. Compare the Results

The evaluation metrics obtained before and after feature scaling are compared to determine the effect of scaling on the model's performance.

---

## Expected Output

The program displays:

* First few rows of the dataset
* Dataset dimensions
* Accuracy, Precision, Recall, and F1-score without feature scaling
* Accuracy, Precision, Recall, and F1-score with feature scaling
* Confusion Matrix
* Classification Report
* Performance comparison of both models

---

## Project Structure

```
project/
│
├── diabetes.csv
├── exp6.py
├── exp6.png
├── output.png
└── README.md
```

---

## Conclusion

The Logistic Regression model successfully predicts whether a patient is diabetic using the Pima Indians Diabetes dataset. Feature scaling with `StandardScaler` generally improves the model's performance by ensuring that all input features contribute equally during training. Comparing the evaluation metrics before and after scaling highlights the importance of preprocessing in machine learning classification tasks.
